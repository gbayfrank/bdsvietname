<?php
/**
 * The template file for the confirmation message.
 *
 * @package    Meta Box
 * @subpackage MB Frontend Submission
 */

?>
<div class="rwmb-confirmation"><?php echo esc_html( $data->confirmation ); ?></div>
