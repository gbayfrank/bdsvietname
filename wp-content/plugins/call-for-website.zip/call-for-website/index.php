<?php
/*
Plugin Name: call For Webssite
Plugin URI: Ngoc Tu
Description: Help your customers easy to contact with your business via call with cool effect.
Author: Ngọc Tú
Version: 1.0
Author URI: http://facebook.com/tututu42
*/
if ( !function_exists( 'add_action' ) ) {
    echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
    exit;
}
define( 'FACEBOOK_MESSENGER_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'FACEBOOK_MESSENGER_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
/*
* Add default options active plugin
*/
function ninja_facebook_messenger_chat_on_plugin_activation() {
    add_option("facebook_messenger_user","01626280179");
}
register_activation_hook( __FILE__, 'ninja_facebook_messenger_chat_on_plugin_activation' );
/*
* Include Back-end
*/
include FACEBOOK_MESSENGER_PLUGIN_DIR."backend/index.php";
/*
* Include Font-end
*/
include FACEBOOK_MESSENGER_PLUGIN_DIR."frontend/index.php";
/*
* Woocommerce
*/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
   include FACEBOOK_MESSENGER_PLUGIN_DIR."backend/woo_commerce.php";
   include FACEBOOK_MESSENGER_PLUGIN_DIR."frontend/woo_commerce.php";
}