<?php
if ( !function_exists( 'add_action' ) ) {
    echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
    exit;
}
function facebook_messenger_shortcode( $atts, $content = null){

	$array = shortcode_atts( array(
        'url' => get_option("facebook_messenger_user"),
        'hide_cover' => (get_option("facebook_messenger_hide_cover")==1)?"true":"false",
        'lagre_header' => (get_option("facebook_messenger_hide_large_header")==1)?"true":"false",
        'button' => "false",
        'id' =>"false"
    ), $atts );
    if ( $array["id"] == "false" ){
        $id ="nj-facebook-messenger-".rand ( 100 , 999 );
    ?>
  <a class="nj-facebook-messenger <?php echo $id ?>_open" href="#"><?php if( $array["button"] == "false"){?><?php echo get_option("facebook_messenger_text_botton") ?> <?php }else{ echo $array["button"];} ?></a>
    <?php }else{
        $id = $array["id"];
    } ?>
  <div id="<?php echo $id ?>" class="facebook_messenger_popup">
        <?php if( $content ){?>
        <div class="facebook-messenger-popup-container">
            <?php echo $content ?>
        </div>
        <?php } ?>
        <div class="fb-page" data-with="350" data-height="310" data-href="<?php echo $array['url'] ?>" data-tabs="messages" data-small-header="<?php if( $array["lagre_header"] == "false"){echo "true";}else{echo "false";} ?>" data-adapt-container-width="true" data-hide-cover="<?php echo $array["hide_cover"] ?>" data-show-facepile="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="<?php echo $array['url'] ?>"><a href="<?php echo $array['url'] ?>">Loading...</a></blockquote></div></div>
  </div>
  <script type="text/javascript">
  jQuery(document).ready(function($) {
      $('#<?php echo $id ?>').popup({
          transition: 'all 0.3s',
          scrolllock: true // optional
        });
    });
  </script>
    <?php
}
add_shortcode( 'fbchat', 'facebook_messenger_shortcode' );
