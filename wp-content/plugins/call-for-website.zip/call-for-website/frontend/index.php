<?php
if ( !function_exists( 'add_action' ) ) {
    echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
    exit;
}
/*
* Add css
*/
add_action( 'wp_print_styles', 'facebook_messenger_chat_add_styles' );
function facebook_messenger_chat_add_styles() {
 if( facebook_messenger_chek_page() ){
    wp_enqueue_style( 'messenger',FACEBOOK_MESSENGER_PLUGIN_URL."frontend/css/messenger.css",array(),"1.0.1" );
}
}
/*
* Add scripts
*/

/*
*
*/
add_action("wp_footer","facebook_mesenger_set_footer_page");
function facebook_mesenger_set_footer_page(){
    if( facebook_messenger_chek_page() ){
        ?>
    <div class="phonering-alo-phone phonering-alo-green phonering-alo-show" id="phonering-alo-phoneIcon">
        <div class="phonering-alo-ph-circle"></div>
        <div class="phonering-alo-ph-circle-fill"></div>
        <div class="phonering-alo-ph-img-circle">
            <a href="tel:<?php echo get_option("facebook_messenger_user"); ?>" class="pps-btn-img " title="Liên hệ">
                <img src="http://i.imgur.com/v8TniL3.png" alt="Liên hệ" width="50" onmouseover="this.src='http://i.imgur.com/v8TniL3.png';" onmouseout="this.src='http://i.imgur.com/v8TniL3.png';">
            </a>
        </div>
    </div>
    <div class="mobile-hotline" id="mobile-hotline">
        <a href="tel:<?php echo get_option("facebook_messenger_user"); ?>" title="tel:<?php echo get_option("facebook_messenger_user"); ?>">
          <span class="text-hotline"><?php echo get_option("facebook_messenger_user"); ?></span>
        </a>
    </div>
    <?php
}
}
/*
* Set background
*/
add_action("wp_head","facebook_messenger_setting_head");
function facebook_messenger_setting_head(){
    ?>
    <?php
}
function facebook_messenger_chek_page(){
   global $wp_query;
   $show = false;
   $post_id = $wp_query->post->ID;
   $type = get_option("facebook_messenger_hide_display");
   if( $type == "1" ) {
        /*
        * Display for pages...
        */
        $all_page = get_option("facebook_messenger_show_page");
        if( is_array( $all_page ) ) {
            if ( is_page() && in_array($post_id,$all_page) ) {
             $show = true;
         }
     }
 }else{
    $all_page = get_option("facebook_messenger_hide_page");
    if( is_array($all_page) ){
        if ( is_page() && in_array($post_id,$all_page) ) {
         $show = false;
     }else{
        $show =true;
    }
}else{
    $show = true;
}
}
return $show;
}