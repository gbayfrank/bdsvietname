(function( $ ) {
    // Add Color Picker to all inputs that have 'color-field' class
    $(function() {
        $('#facebook_messenger_backgroud').wpColorPicker();
    });
    var fileInput = '';
    jQuery('#fecebook-messenger-upload').click(function() {
        fileInput = jQuery(this).prev('input');
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        return false;
    });
    window.send_to_editor = function(html) {
     imgurl = jQuery('img',html).attr('src');
     fileInput.val(imgurl);
     tb_remove();
    }
    $("#facebook-messenger-checkall").change(function(){
        $(".facebook_messenger_hide_page").prop('checked', $(this).prop("checked"));
    })
    $("#facebook-messenger-checkall-1").change(function(){
        $(".facebook_messenger_show_page").prop('checked', $(this).prop("checked"));
    })
    $("#ninja-display-messenger").change(function(){
        var id = $(this).val();
        if ( id == 1 ) {
            $("#facebook-messenger-tr-show").removeClass("hidden");
            $("#facebook-messenger-tr-hide").addClass("hidden");
        }else{
            $("#facebook-messenger-tr-hide").removeClass("hidden");
            $("#facebook-messenger-tr-show").addClass("hidden");
        }
    })
})( jQuery );