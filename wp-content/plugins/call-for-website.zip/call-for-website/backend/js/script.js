jQuery(document).ready(function($) {
    $("#facebook_messenger_custom").change(function(){
        $(".nj-facebook_messenger").toggleClass("hidden");
    })
});
