<?php
if ( !function_exists( 'add_action' ) ) {
    echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
    exit;
}
/*
* Add menu admin options
*/
add_action( 'admin_menu', 'facebook_messenger_menu_options' );
function facebook_messenger_menu_options(){
    add_submenu_page( 'options-general.php', 'Call For Webssite', 'Call For Webssite', 'manage_options', 'facebook_messenger_options_page', 'facebook_messenger_options_page' );
}
/*
* Add Upload style and script
*/
add_action( 'admin_enqueue_scripts', 'facebook_messenger_admin_enqueue_scripts' );
function facebook_messenger_admin_enqueue_scripts(){
    $page = @$_GET["page"];
    if ( $page == "facebook_messenger_options_page" ) {
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script('media-upload');
        wp_enqueue_script('facebook-messenger-settings', FACEBOOK_MESSENGER_PLUGIN_URL . 'backend/js/settings.js',array( 'jquery', 'wp-color-picker' ),'',true);
    }
}
function facebook_messenger_admin_style() {
    wp_enqueue_style('thickbox');
    wp_enqueue_style( 'facebook-messenger-style', FACEBOOK_MESSENGER_PLUGIN_URL."backend/css/style.css" );
}
add_action('admin_print_styles', 'facebook_messenger_admin_style');
/*
* Add form options
*/
function facebook_messenger_options_page(){
    ?>
    <div class="wrap">
        <form action="options.php" method="post" id="nj-fb-class">
        <?php settings_fields("wap_form") ?>
          <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="facebook_messenger_user"><?php echo __("Mời bạn nhập Số điện thoại","fb_messenger") ?></label></th>
                    <td>
                        <input name="facebook_messenger_user" id="facebook_messenger_user" type="text" value="<?php echo get_option("facebook_messenger_user"); ?>" class="regular-text" />
                         <p class="description" id="tagline-description"><?php echo __("SĐT: 01685431282","fb_messenger") ?></p>
                    </td>
                </tr>
          
             </table>
             <?php submit_button("Save") ?>
			 </form>
      </div>
    <?php
}
/*
* Save options
*/
add_action("admin_init","fb_live_chat_save_form");
function fb_live_chat_save_form(){
    register_setting("wap_form","facebook_messenger_lang");
    register_setting("wap_form","facebook_messenger_backgroud");
    register_setting("wap_form","facebook_messenger_user");
    register_setting("wap_form","facebook_messenger_hide_cover");
    register_setting("wap_form","facebook_messenger_hide_display");
    register_setting("wap_form","facebook_messenger_hide_page");
    register_setting("wap_form","facebook_messenger_show_page");
    register_setting("wap_form","facebook_messenger_hide_large_header");
    register_setting("wap_form","facebook_messenger_text_img");
    register_setting("wap_form","facebook_messenger_text_botton");
    if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
        register_setting("wap_form","facebook_messenger_woo_position");
    }
}